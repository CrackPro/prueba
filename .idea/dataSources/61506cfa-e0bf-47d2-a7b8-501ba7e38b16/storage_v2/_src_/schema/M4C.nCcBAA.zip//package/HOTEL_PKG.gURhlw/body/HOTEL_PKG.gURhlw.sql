create PACKAGE BODY  hotel_pkg
AS
  TYPE hotel_type IS REF CURSOR
  RETURN hotel%ROWTYPE;
END hotel_pkg;
/

