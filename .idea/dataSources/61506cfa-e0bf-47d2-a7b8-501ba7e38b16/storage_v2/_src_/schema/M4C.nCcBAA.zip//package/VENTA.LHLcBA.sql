create PACKAGE VENTA AS
  /** 
    * Proyecto:         Marketing
    * Descripción:     Módulo de Ventas
    * Impacto a BD:   No
    */
/**
* Obtiene el saldo de la activación 
*
* @pidbooking idbooking del cliente
*/
  FUNCTION GET_PAGOACTIVACION( pidbooking number) RETURN number;
END VENTA;
/

