create PROCEDURE FILTER_TEST (
            idCCenter IN INT,
            fiReservacion IN DATE,
            ffReservacion IN DATE,            
            listadoClientes__ OUT SYS_REFCURSOR
)
    IS
BEGIN dd
    DECLARE BEGIN
        OPEN listadoClientes__ FOR SELECT
            DISTINCT C.IDCLIENTE AS CLIENT ,C.IDUSER, 
            regexp_replace(C.CELULAR, '?[a-zA-Z|[-]|[.]|[(]|[)]|[[:space:]]*', '') AS cellSinCaracteres, R.IDBOOKING
            FROM M4CLIENTE C, M4CRESERVACION R WHERE R.FECHA_RESERVACION BETWEEN TO_DATE(fiReservacion,'dd/MM/yyyy')
            AND TO_DATE(ffReservacion,'dd/MM/yyyy') AND C.IDCLIENTE = R.IDCLIENTE 
            AND C.IDCALLCENTER = idCCenter AND C.PAIS = 'USA' AND C.CELULAR IS NOT NULL
            AND (select round(nvl((select SUM(IMPORTE) from m4cservicioscontratados where idbooking=v.idbooking and idreservacion is null 
            and idsubservicio in (select idsubservicio from m4csubservicios 
            where idservicio = 1 and idservicio = 2 and idservicio = 10 and idservicio = 30)  ),0)-nvl((select SUM(IMPORTE/case when (c.idcallcenter not in(7,21,261)) then ntipocambio else 1 
            end) from m4cpagosservicios where idbooking=v.idbooking and numautorizacion is not null),0),2)
            from m4cventa v, m4cliente c where c.idcliente=v.idcliente and v.idbooking=R.IDBOOKING) <10;     
    END;
END;
/

