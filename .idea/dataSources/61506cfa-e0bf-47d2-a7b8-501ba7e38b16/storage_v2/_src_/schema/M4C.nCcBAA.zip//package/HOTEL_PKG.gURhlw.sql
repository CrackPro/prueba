create PACKAGE hotel_pkg IS
    TYPE hotel_type IS REF CURSOR;
     RETURN M4CUNIDADES_HOTEL%ROWTYPE;
END hotel_pkg;
/

