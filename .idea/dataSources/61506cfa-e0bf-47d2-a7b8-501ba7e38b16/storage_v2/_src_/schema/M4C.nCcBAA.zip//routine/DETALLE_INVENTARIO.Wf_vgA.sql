create FUNCTION     DETALLE_INVENTARIO  (fecha_inicio in DATE, fecha_fin DATE)RETURN VARCHAR

DECLARE
   lv_sql          VARCHAR (32767);
  /

