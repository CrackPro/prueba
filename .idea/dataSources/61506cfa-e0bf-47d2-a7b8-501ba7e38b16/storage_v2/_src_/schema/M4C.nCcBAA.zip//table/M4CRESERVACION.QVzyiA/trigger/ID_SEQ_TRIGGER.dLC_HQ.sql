create trigger ID_SEQ_TRIGGER
  before insert
  on M4CRESERVACION
  for each row
  BEGIN
    IF :new.IDRESERVACION IS NULL THEN
      SELECT RESERVATION_SEQ.nextval INTO :new.IDRESERVACION FROM DUAL;
    END IF;
  END;
/

