create trigger M4CSOBREVENTA_LOG_TRIGGER
  before insert or update of SOLICITUD, NOTAS, CONSULTOR, F_LLEGADA, F_SALIDA, HUESPED, IDHABITACION, AUTORIZADA, EXPIRA, UTILIZADA, CANTIDAD
  on M4CSOBREVENTA
  for each row
  declare 
BEGIN
   declare
      p_operacion varchar(20);
   BEGIN
      p_operacion :=null;

   if ( INSERTING  )
     then
   p_operacion :='creacion';
   end if;
   if ( UPDATING) then

        IF(
        :NEW.AUTORIZADA!=:OLD.AUTORIZADA AND :NEW.AUTORIZADA=0
        ) then
            p_operacion :='reenvio';
        end if;

        IF(
        :NEW.EXPIRA>sysdate AND :OLD.EXPIRA<sysdate
        ) then
            p_operacion :='reenvio';
        end if;

          IF(
          :NEW.IDHABITACION!=:OLD.IDHABITACION 
          or :NEW.HUESPED!=:OLD.HUESPED 
          or :NEW.CANTIDAD!=:OLD.CANTIDAD 
          or :NEW.F_LLEGADA!=:OLD.F_LLEGADA 
          or :NEW.F_SALIDA!=:OLD.F_SALIDA
          ) then
                p_operacion :='cambio';
          end if;

          IF(
           :NEW.SOLICITUD!=:OLD.SOLICITUD 
          ) then
                p_operacion :='cambio agencia';
          end if;

        IF(
        :NEW.AUTORIZADA!=:OLD.AUTORIZADA AND :NEW.AUTORIZADA=1
        ) then
            p_operacion :='autorizacion';
        end if;

        IF(
        :NEW.AUTORIZADA!=:OLD.AUTORIZADA  AND :NEW.AUTORIZADA=-1
        ) then
            p_operacion :='declinacion';
        end if;

        IF(
        :NEW.UTILIZADA!=:OLD.UTILIZADA AND :NEW.UTILIZADA=1
        ) then
            p_operacion :='utilizacion';
        end if;

        IF(
        :NEW.EXPIRA!=:OLD.EXPIRA AND :NEW.EXPIRA<sysdate
        ) then
            p_operacion :='cancelacion';
        end if;

    end if;

      if(p_operacion is not null) then
              INSERT INTO M4CSOBREVENTA_LOG
              (
                 ID
                ,OPERACION
                ,CANTIDAD
                ,FECHALLEGADA
                ,FECHASALIDA
                ,IDUNIDAD
                ,HUESPED
                ,CONSULTOR
                ,COMENTARIOS
                ,AUTORIZA
                ,RAZON_NEGACION
                ,SOLICITUD
                ,FECHA
              )
              VALUES
              (
           -- M4CSOBREVENTA_SEQ.NEXTVAL
              M4CSOBREVENTA_SEQ.NEXTVAL
              ,p_operacion
              ,:NEW.CANTIDAD
              ,:NEW.F_LLEGADA
              ,:NEW.F_SALIDA
              ,:NEW.IDHABITACION
              ,:NEW.HUESPED
              ,:NEW.CONSULTOR
              ,:NEW.NOTAS
              ,:NEW.AUTORIZA
              ,:NEW.RAZON_NEGACION
              ,:NEW.SOLICITUD
              ,sysdate
              );
      end if;
    END;
  NULL;
END;
/

