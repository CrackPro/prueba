create PROCEDURE obtener_cursor (PN_CODIGO IN NUMBER,PC_CURSOR OUT Sys_Refcursor,PV_ERROR  OUT VARCHAR2) 
IS lv_programa VARCHAR2(100) := 'pr_obtener_cursor';
  BEGIN
     IF PN_CODIGO IS NULL THEN
       PV_ERROR := 'no puede ser nulo';
       RETURN;
    END IF;
     OPEN PC_CURSOR FOR
           SELECT *
            FROM M4CUNIDADES_HOTEL T
           WHERE T.HOTEL_ID= PN_CODIGO
             AND T.UNIDAD IN ('UH');
   EXCEPTION
    WHEN NO_DATA_FOUND THEN
         pv_error:='CÃƒï¿½Ã‚Â³digo no existe';
    WHEN OTHERS THEN
         pv_error:= lv_programa ||'-'||Sqlerrm;
  END obtener_cursor;
/

