create trigger PLANTILLAEMAIL_DEFAULT_CONTEXT
  before insert
  on M4CPLANTILLAEMAIL
  for each row
  DECLARE
   
BEGIN
  	IF :NEW.CONTEXT_ID is null 
	THEN       
	       -- Update context id with context 2(certmanager)
		   :NEW.CONTEXT_ID := 2;
	END IF;
END;
/

