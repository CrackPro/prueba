create view M4C_AGENT_LIST as
  SELECT usermarketing.IDUSER, usermarketing.ACTIVO,
(SELECT userinventario.nombre FROM usuario@inventariom4c userinventario WHERE userinventario.usuario_id = usermarketing.IDUSER) AS nombre,
usermarketing.EXTENSION,
usermarketing.EMAIL,
usermarketing.IDDEPTO
FROM M4C.M4CUSUARIOS usermarketing
/

