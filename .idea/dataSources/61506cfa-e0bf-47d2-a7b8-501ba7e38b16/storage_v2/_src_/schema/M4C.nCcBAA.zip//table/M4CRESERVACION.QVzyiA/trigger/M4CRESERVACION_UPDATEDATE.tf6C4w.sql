create trigger M4CRESERVACION_UPDATEDATE
  before insert or update
  on M4CRESERVACION
  for each row
  BEGIN
  :new.FECHA_CAMBIO := sysdate;
END;
/

