create trigger AUTO_MC4PROYECCIONES
  before insert
  on M4CPROYECCIONES
  for each row
  BEGIN
IF :new.ID is NULL THEN
  SELECT m4cproy_seq.NEXTVAL
  INTO   :new.ID
  FROM   dual;
  end if;
END;
/

