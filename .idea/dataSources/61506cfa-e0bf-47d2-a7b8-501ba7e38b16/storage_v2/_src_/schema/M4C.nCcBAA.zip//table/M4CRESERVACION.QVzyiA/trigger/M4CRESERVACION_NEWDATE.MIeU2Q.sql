create trigger M4CRESERVACION_NEWDATE
  before insert
  on M4CRESERVACION
  for each row
  BEGIN
    :new.FECHA_RESERVACION := sysdate;
  END;
/

