create PROCEDURE DETALLES(f_i DATE, f_f DATE, hotel NUMBER, segmento NUMBER) IS
     lv_sql VARCHAR(32767);
     lv_pivot_cols VARCHAR2(32767);
    TYPE CUR_TYP IS REF CURSOR;
    v_cur  CUR_TYP;
    BEGIN
         FOR i IN (SELECT DISTINCT FECHA FROM  M4CINVENTARIO_ASIGNACION where trunc(fecha) between ('01/10/2017') and ('07/10/2017') and HOTEL_ID = 8 and IDSEGMENTO = 4 )
         LOOP
              lv_pivot_cols := lv_pivot_cols ||'('||''''||i.FECHA||''''||','|| '''' || i.FECHA ||''''||')'||',';
         END LOOP;
         lv_pivot_cols := RTRIM(lv_pivot_cols,',');

         lv_sql := 'SELECT * FROM   M4CINVENTARIO_ASIGNACION';

     EXECUTE IMMEDIATE lv_sql;
         DBMS_OUTPUT.put_line(lv_sql);
--         open v_cur;
      --CLOSE v_cur;
END DETALLES;
/

