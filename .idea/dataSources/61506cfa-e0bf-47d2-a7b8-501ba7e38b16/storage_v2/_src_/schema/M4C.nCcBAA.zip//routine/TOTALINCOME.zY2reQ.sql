create Function TotalIncome
   ( name_in IN varchar2 )
   RETURN varchar2
IS
   total_val number(6);

   cursor c1 is
     SELECT UNIDAD
     FROM M4CUNIDADES_HOTEL
     WHERE UNIDAD = name_in;

BEGIN

   total_val := 0;

   FOR employee_rec in c1
   LOOP
      total_val := total_val + employee_rec.UNIDAD;
   END LOOP;

   RETURN total_val;

END;
/

