create PROCEDURE     p1 (f_i        IN     DATE,
                                    f_f        IN     DATE,
                                    habitaciones IN   VARCHAR, 
                                    hotel      IN     INT,
                                    segmento   IN     VARCHAR,
                                    grupo   IN     VARCHAR,                                    
                                    lv_sql        OUT VARCHAR)
IS 
    habitacion      VARCHAR2 (6000);
    lv_pivot_cols   VARCHAR2 (32767);

    TYPE hotel_type IS REF CURSOR;

    c1              hotel_type;

    TYPE MyRec IS RECORD
    (
        col1    VARCHAR2 (6000),
        col2    VARCHAR2 (2000)
    );                                                     --define the record

    campos          MyRec;
BEGIN
    FOR i IN (SELECT TO_DATE (f_i) + ROWNUM - 1 AS FECHA
                FROM M4CINVENTARIO_ASIGNACION
               WHERE ROWNUM <= TO_DATE (f_f) - TO_DATE (f_i) + 1)
    --SELECT DISTINCT FECHA FROM  M4CINVENTARIO_ASIGNACION where  M4CINVENTARIO_ASIGNACION.FECHA between to_date(f_i) and to_date(f_f) and M4CINVENTARIO_ASIGNACION.HOTEL_ID=hotel and M4CINVENTARIO_ASIGNACION.IDSEGMENTO IN (SEGMENTO))
    LOOP
        lv_pivot_cols :=
               lv_pivot_cols
            || ''''
            || i.FECHA
            || ''''
            || ' as '
            || '"'
            || i.FECHA
            || '"'
            || ',';
    END LOOP;

    lv_pivot_cols := RTRIM (lv_pivot_cols, ',');
    lv_sql :=
           'SELECT distinct * FROM
     (SELECT M4CUNIDADXHOTEL.NOMBREUNIDAD,
      M4CUNIDADXHOTEL.CLAVEUNIDAD,FECHA,ASIGNADO,
     SUM( M4CINVENTARIO_ASIGNACION.ASIGNADO ) OVER ( PARTITION BY M4CINVENTARIO_ASIGNACION.CLAVEUNIDAD ) AS T_ASIGNADO
     FROM   M4CINVENTARIO_ASIGNACION INNER JOIN M4CUNIDADXHOTEL ON (M4CINVENTARIO_ASIGNACION.CLAVEUNIDAD=M4CUNIDADXHOTEL.ID)
     where M4CUNIDADXHOTEL.GRUPO IN
     ('||  grupo || ') AND  M4CINVENTARIO_ASIGNACION.FECHA  between to_date('
        || ''''
        || f_i
        || ''''
        || ') and to_date('
        || ''''
        || f_f
        || ''''
        || ') and M4CUNIDADXHOTEL.CLAVEUNIDAD in ('
        ||  habitaciones
        || ') 
        and M4CINVENTARIO_ASIGNACION.HOTEL_ID= '
        || hotel
        || ' and M4CINVENTARIO_ASIGNACION.IDSEGMENTO in ('
        ||  segmento
        || ')) 
PIVOT (
                    SUM(ASIGNADO) AS A
                    FOR (FECHA) IN ('
        || lv_pivot_cols
        || ')) order by 1';
    DBMS_OUTPUT.PUT_LINE (lv_sql);
END p1;
/

