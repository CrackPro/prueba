create FUNCTION     YEAR_AMMOUNT  (fecha_inicio in DATE, fecha_fin DATE)RETURN VARCHAR

DECLARE
   lv_sql          VARCHAR (32767);
  /

