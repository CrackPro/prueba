create PROCEDURE datos_hotel
  (
  par1 IN VARCHAR2,
  par2 IN VARCHAR2,
  cursor1 OUT hotel_pkg.hotel_type
  )
AS
BEGIN
  /* Todos los parámetros tienen valor */
  IF par1 IS NOT NULL AND par2 IS NOT NULL
  THEN
    OPEN cursor1 FOR
    SELECT * FROM M4CUNIDADES_HOTEL
    WHERE UNIDAD = par1
      AND UNIDAD_HOTEL = par2;
    ELSIF par1 IS NOT NULL
  THEN
    OPEN cursor1 FOR
    SELECT * FROM M4CUNIDADES_HOTEL
    WHERE UNIDAD = par1;
  ELSIF par2 IS NOT NULL
  THEN
    OPEN cursor1 FOR
    SELECT * FROM M4CUNIDADES_HOTEL
    WHERE UNIDAD_HOTEL = par2;
  END IF;
     FOR employee_rec in cursor1
   LOOP
      total_val := total_val + employee_rec.UNIDAD;
   END LOOP;

END datos_hotel;
/

