create view M4CPICKUPS_LLEGADAS_SIN_VUELO as
  select r.CHECKIN as SFECHA,r.CHECKIN as LLEGADA, r.CHECKOUT as SALIDA, upper(to_char(r.CHECKIN, 'day')) as DIA,
(select NOMBRE||' '||APELLIDO from m4creservacionpax where idreservacion=r.IDRESERVACION and rownum=1 ) as NOMBRE,
'N/A' as ORIGEN, 
(select nombre from m4chotel where HOTEL_ID= r.HOTEL_ID) as DESTINO, '' as OPERADOR,
'NO PICKUP' as VUELO, '00:00' as HORA, r.TOTAL_ADULTO||'.'||r.TOTAL_MENOR as PAX,
c.NOMBRE AS CALLCENTER,1 as total_pickups, 
to_number(r.TOTAL_ADULTO||'.'||r.TOTAL_MENOR) as NPAX , cp.CLAVE as PROGRAMA,r.IDRESERVACION, TO_NUMBER(round(dbms_random.value() * 20000) + cliente.IDCLIENTE + r.IDRESERVACION) as ID, 0 as IDPICKUP, r.numconfirmacion, r.numconfirmacion as confirma
from M4CRESERVACION r, M4CCALLCENTER c, M4CLIENTE cliente, m4ccatprogramas cp
where cliente.IDCLIENTE = r.IDCLIENTE
and c.IDCALLCENTER= cliente.IDCALLCENTER
and cp.idprograma=r.idprograma
and r.IDRESERVACION not in (select RESERVACION_ID from M4CRESERVACION_PICKUP)
and r.STATUS in ('10','57') 
AND (R.SEGMENTO IS NULL OR R.SEGMENTO NOT IN (6) )
order by 1 desc
/

