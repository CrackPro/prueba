create view M4CPICKUPS_LLEGADAS_CON_VUELO as
  select p.FECHA as SFECHA, p.FECHA as LLEGADA,r.CHECKOUT as SALIDA, upper(to_char(p.FECHA, 'day')) as DIA, 
p.NOMBRE||' '||p.APELLIDO||nvl((select '['||count(*)||']' from  M4CRESERVACION_PICKUP where RESERVACION_ID = r.idreservacion and PICKUP_ID in (select ID from M4CPICKUP where TIPO='Llegada') having count(*)>1),'') as NOMBRE,  p.ORIGEN as ORIGEN, 
p.DESTINO as DESTINO,oper.NOMBRE as OPERADOR,
 p.AEROLINEA||' '||p.VUELO as VUELO,  to_char(p.FECHA, 'HH24:MI') as HORA, 
to_char(p.PAX,'99.9') as PAX,
c.NOMBRE AS CALLCENTER,
1 as total_pickups,
p.PAX as NPAX , cp.CLAVE as PROGRAMA, r.IDRESERVACION, p.ID as IDPICKUP, p.ID, r.numconfirmacion , r.numconfirmacion as confirma
from  M4CRESERVACION_PICKUP rp, M4CRESERVACION r, M4CCALLCENTER c, M4CLIENTE cliente , m4ccatprogramas cp,M4CPICKUP p
LEFT JOIN M4COPERADOR oper on  oper.ID = p.OPERADOR_ID
where rp.RESERVACION_ID=r.IDRESERVACION and p.ID=rp.PICKUP_ID 
and cliente.IDCLIENTE = r.IDCLIENTE
and c.IDCALLCENTER= cliente.IDCALLCENTER
and cp.idprograma=r.idprograma
and p.TIPO='Llegada' 
and r.STATUS in ('10','57')
AND (R.SEGMENTO IS NULL OR R.SEGMENTO NOT IN (6) )
order by 1 desc

/

