create view M4CVIEWCALLCENTERS as
  select cc.idcallcenter,ca.idcampania, cc.nombre||'/'||campania as nombre
from m4ccallcenter cc, (SELECT * FROM M4CCATCAMPANA WHERE IDCALLCENTER in (2003)) ca where cc.idcallcenter=ca.idcallcenter(+) and ingresos=1 and cc.activo=1 order by 3
/

