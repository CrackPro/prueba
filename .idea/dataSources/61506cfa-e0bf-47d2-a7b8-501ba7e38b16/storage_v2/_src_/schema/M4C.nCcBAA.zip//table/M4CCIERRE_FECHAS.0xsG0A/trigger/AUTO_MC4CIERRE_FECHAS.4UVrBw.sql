create trigger AUTO_MC4CIERRE_FECHAS
  before insert
  on M4CCIERRE_FECHAS
  for each row
  BEGIN
IF :new.ID is NULL THEN
  SELECT M4CCIERRE_FECHAS_SEQ.NEXTVAL
  INTO   :new.ID
  FROM   dual;
    end if;
END;
/

