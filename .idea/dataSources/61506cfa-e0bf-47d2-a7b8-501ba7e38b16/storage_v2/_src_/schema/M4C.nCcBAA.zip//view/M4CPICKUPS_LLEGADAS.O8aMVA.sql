create view M4CPICKUPS_LLEGADAS as
  select p.FECHA as SFECHA, p.FECHA as LLEGADA,r.CHECKOUT as SALIDA, upper(to_char(p.FECHA, 'day')) as DIA, 
p.NOMBRE||' '||p.APELLIDO||nvl((select '['||count(*)||']' from  M4CRESERVACION_PICKUP where RESERVACION_ID = r.idreservacion and PICKUP_ID in (select ID from M4CPICKUP where TIPO='Llegada') having count(*)>1),'') as NOMBRE,  p.ORIGEN as ORIGEN, 
p.DESTINO as DESTINO,oper.NOMBRE as OPERADOR,
 p.AEROLINEA||' '||p.VUELO as VUELO,  to_char(p.FECHA, 'HH24:MI') as HORA, 
p.PAXS as PAX,
c.NOMBRE AS CALLCENTER,
1 as total_pickups,
p.PAX as NPAX , cp.CLAVE as PROGRAMA, r.IDRESERVACION, p.ID as IDPICKUP, p.ID, r.numconfirmacion , r.numconfirmacion as confirma
from  M4CRESERVACION_PICKUP rp, M4CRESERVACION r, M4CCALLCENTER c, M4CLIENTE cliente , m4ccatprogramas cp,M4CPICKUP p
LEFT JOIN M4COPERADOR oper on  oper.ID = p.OPERADOR_ID
where rp.RESERVACION_ID=r.IDRESERVACION and p.ID=rp.PICKUP_ID 
and cliente.IDCLIENTE = r.IDCLIENTE
and c.IDCALLCENTER= cliente.IDCALLCENTER
and cp.idprograma=r.idprograma
and p.TIPO='Llegada' 
and r.STATUS in ('10','57')
AND (R.SEGMENTO IS NULL OR R.SEGMENTO NOT IN (6) )
union 
select r.CHECKIN as SFECHA,r.CHECKIN as LLEGADA, r.CHECKOUT as SALIDA, upper(to_char(r.CHECKIN, 'day')) as DIA,
(select NOMBRE||' '||APELLIDO from m4creservacionpax where idreservacion=r.IDRESERVACION and rownum=1 ) as NOMBRE,
'N/A' as ORIGEN, 
(select nombre from m4chotel where HOTEL_ID= r.HOTEL_ID) as DESTINO, '' as OPERADOR,
'NO PICKUP' as VUELO, '00:00' as HORA, r.TOTAL_ADULTO||'.'||r.TOTAL_MENOR as PAX,
c.NOMBRE AS CALLCENTER,1 as total_pickups, 
to_number(r.TOTAL_ADULTO||'.'||r.TOTAL_MENOR) as NPAX , cp.CLAVE as PROGRAMA,r.IDRESERVACION, 0 as ID, 0 as IDPICKUP, r.numconfirmacion, r.numconfirmacion as confirma
from M4CRESERVACION r, M4CCALLCENTER c, M4CLIENTE cliente, m4ccatprogramas cp
where cliente.IDCLIENTE = r.IDCLIENTE
and c.IDCALLCENTER= cliente.IDCALLCENTER
and cp.idprograma=r.idprograma
and r.IDRESERVACION not in (select RESERVACION_ID from M4CRESERVACION_PICKUP)
and r.STATUS in ('10','57') 
AND (R.SEGMENTO IS NULL OR R.SEGMENTO NOT IN (6) )
order by 1 desc

/

