create PACKAGE BODY VENTA AS   
  FUNCTION GET_PAGOACTIVACION(pidbooking number) RETURN number
  AS
    saldo number:=0;
    booking number:=0;
    pagosreserva number:=0;
    pagosbooking number:=0;
    saldoventas number:=0;
    pagosbooking2 number:=0;
  BEGIN
    select to_number(nvl(idbooking,0)) into booking from M4cventa where idbooking=pidbooking;
    if(booking>0) then
      select nvl(sum(importe),0) into saldoventas from m4cservicioscontratados  where idbooking=booking and idsubservicio in (
      select idsubservicio from m4csubservicios where idservicio=9);

      select nvl(sum(sp.IMPORTE),0) into pagosbooking from M4CSERVICIOSPAGADOS sp, M4CPAGOSSERVICIOS rp
      where rp.IDBOOKING=sp.IDBOOKING and rp.idpago=sp.IDPAGO and rp.idbooking=booking and 
      sp.IDSERVCONTRATADO in 
      (select sc.IDSERVCONTRATADO from m4cservicioscontratados sc, m4csubservicios sus
       where sc.IDSUBSERVICIO=sus.IDSUBSERVICIO and sus.IDSERVICIO=9 and sc.IDBOOKING=booking 
      );

      select nvl(sum(sp.IMPORTE),0) into pagosbooking2 from M4CSERVICIOSPAGADOS sp, M4CRESPAGOS rp
      where rp.IDRESERVACION=sp.IDRESERVACION and rp.idpago=sp.IDPAGO and sp.IDBOOKING=booking and
      sp.IDSERVCONTRATADO in 
      (select sc.IDSERVCONTRATADO from m4cservicioscontratados sc, m4csubservicios sus
       where sc.IDSUBSERVICIO=sus.IDSUBSERVICIO and sus.IDSERVICIO=9 and sc.IDBOOKING=booking 
      );
    end if;
  saldo:= saldoventas-(pagosbooking+pagosreserva+pagosbooking2);
  if( saldo < 5) then
    saldo:=0;
   end if;
  RETURN saldo;  
  END GET_PAGOACTIVACION;
END VENTA;
/

